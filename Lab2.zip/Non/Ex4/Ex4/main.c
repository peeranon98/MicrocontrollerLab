#include <avr/io.h>
#define LED_BIT 5 // Bit position of LED
#define SW_BIT 7 // Bit position of switch
#define LED 1<<LED_BIT // Bit mask for LED
#define SW 1<<SW_BIT // Bit mask for Switch
#define MAX_CNT 2 // Maximum number for counting
#define tByte unsigned char
volatile tByte i=0;
volatile tByte sw_cur=1; // Current state of switch
volatile tByte sw_prv; // Previous state of switch
void fSwDebounce(void) {
	if (sw_cur) {
		if ((PIND&SW)==0) { // Check if switch is pressed
			i++;
			if (i>=MAX_CNT) { // Check # of consecutive 0s
				sw_cur=0; // Switch is assumed On
				i=0;
			}
		} else i=0;
		} else {
		if ((PIND&SW)) { // Check if switch is released
			i++;
			if (i>=MAX_CNT) { // Check # of consecutive 1s
				sw_cur=1; // Switch is assumed Off
				i=0;
			}
		} else i=0;
	}
}
int main(void)
{
	DDRB |= LED;
	PORTB = 0x00;
	sw_prv=sw_cur;
	while (1)
	{
		fSwDebounce(); // Deboucing
		if (sw_cur!=sw_prv) {
			PORTB ^= LED; // Toggle LED
			sw_prv=sw_cur;
		}
	}
}