/*
 * Ex2.c
 *
 * Created: 2/8/2019 2:30:36 AM
 * Author : netlab
 */ 

#include <avr/io.h>
#define F_CPU 16000000UL
#include "util/delay.h"

#define tByte unsigned char

#define MAX_DIG 10
#define DIG0 0b00111111
#define DIG1 0b00000110
#define DIG2 0b01011011
#define DIG3 0b01001111
#define DIG4 0x66
#define DIG5 0x6D
#define DIG6 0x7D
#define DIG7 0b00000111
#define DIG8 0b01111111
#define DIG9 0b01101111



const tByte DispTable[] = {
	DIG0,DIG1,DIG2,DIG3,DIG4,DIG5,DIG6,DIG7,DIG8,DIG9
};

volatile tByte i=0;

void fDispDig(tByte d){
	PORTC = (d&0b00001111);
	PORTD = (d&0b01110000);	
}

int main(void)
{
    /* Replace with your application code */
	DDRC = 0b00001111;
	DDRD = 0b01110000;
	fDispDig(DIG0);
    while (1) 
    {
		if ((PIND&0b10000000)==0){
			i++;
			if (i>=MAX_DIG) i=0;
			fDispDig(DispTable[i]);
			_delay_ms(200);
			{
			}
		}
		
    }
}

