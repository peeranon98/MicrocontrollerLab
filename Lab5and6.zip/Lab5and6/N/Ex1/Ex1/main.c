#include <avr/io.h>
#include <stdio.h>
#define F_CPU 16000000UL
#define BAUD 9600
#include <util/setbaud.h>
#include <util/delay.h>
void uart_putchar(char c, FILE *stream) {
	if (c == '\n') uart_putchar('\r', stream);
	loop_until_bit_is_set(UCSR0A, UDRE0);
	UDR0 = c;
}
char uart_getchar(FILE *stream) {
	loop_until_bit_is_set(UCSR0A, RXC0);
	return UDR0;
}
FILE uart_output = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);
FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getchar, _FDEV_SETUP_READ);
void fPrintfInit(void) {
	UBRR0H = UBRRH_VALUE;
	UBRR0L = UBRRL_VALUE;
	UCSR0A &= ~(_BV(U2X0));
	UCSR0C = _BV(UCSZ01) | _BV(UCSZ00);
	UCSR0B = _BV(RXEN0) | _BV(TXEN0);
	stdout = &uart_output;
	stdin = &uart_input;
}
int main(void) {
	unsigned int adc_rd;
	fPrintfInit();
	ADMUX |= (1<<REFS1)|(1<<REFS0); // Vref =1.1V
	ADMUX |= (1<<ADLAR); // 8-bit output
	ADMUX |= (1<<MUX3); // Select Temp Sensor
	ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); // CLKadc=CLKsys/128
	ADCSRA |= (1<<ADEN); // ADC Enabled
	while(1) {
		ADCSRA |= (1<<ADSC); // Start conversion
		while (ADCSRA&(1<<ADSC)); // Wait until conversion done
		adc_rd = ADCH; // Read 8-bit ADC output
		printf("ADC = %d\n",adc_rd); // Show result
		_delay_ms(1000); // Pause a second
	}
	return 0;
}