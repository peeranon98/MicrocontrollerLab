#include <avr/io.h>
#include <avr/interrupt.h>
#define LED PB5
void fSClkPrescaler() {
	cli(); // Clear global intr flag
	CLKPR = 0b10000000; // Enable CLKPR change
	CLKPR = 0b00000001; // Set System Clock Prescaler
}
void fInitTimer() {
	fSClkPrescaler();
	TCCR0A &= ~((1<<WGM01)|(1<<WGM00)); // Set Timer0 to Normal mode
	TIMSK0 |= (1<<TOIE0); // Overflow Intr enabled
	// Select timer0's clock source
	TCCR0B |= (1 << CS02) | (1 << CS00); // ClockIO / 1024
	sei(); // Enable global interrupts
}
int main(void) {
	DDRB |= _BV(LED); // Set pin directions
	PORTB &= ~_BV(LED); // Turn off LED
	fInitTimer(); // Set Timer0
	while (1) {}
}
// Timer0'Overflow ISR
ISR (TIMER0_OVF_vect) {
	PORTB ^= _BV(LED); // Toggle LED
}