/*
 * ex1.c
 *
 * Created: 1/25/2019 2:06:49 AM
 * Author : netlab
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

