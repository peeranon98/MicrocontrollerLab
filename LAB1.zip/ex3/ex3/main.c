/*
 * ex3.c
 *
 * Created: 1/25/2019 2:25:35 AM
 * Author : netlab
 */ 

#include <avr/io.h>
#define F_CPU 16000000UL
#include "util/delay.h"

int main(void)
{
	DDRC = 0b00000011;
	DDRB = 0b00000000;
	PORTC = 0b00000000;
    /* Replace with your application code */
	PORTB = 0b00000001;
    while (1) 
    {
		PORTC = 0b00000001;
		_delay_ms(500);
		PORTC = 0b00000010;
		_delay_ms(500);
		while ((PINB&0b00000001)==0)
		{
			PORTC = 0b00000000;
		}
    }
}

