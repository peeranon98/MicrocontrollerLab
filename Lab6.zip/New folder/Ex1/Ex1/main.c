#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#define tByte unsigned char
#define RS PB0
#define E PB1
#define BUF_SIZE 16
#define DELAY 2
void f8BitWriteCmd(tByte c) {
	PORTB &= ~(1<<RS);
	PORTD = c;
	PORTB |= (1<<E);
	PORTB &= ~(1<<E);
	_delay_ms(DELAY);
}
void f8BitWriteDat(tByte d) {
	PORTB |= (1<<RS);
	PORTD = d;
	PORTB |= (1<<E);
	PORTB &= ~(1<<E);
	_delay_ms(DELAY);
}
void f4BitWriteCmd(tByte c) {
	PORTB &= ~_BV(RS);
	PORTD = c;
	PORTB |= _BV(E);
	PORTB &= ~_BV(E);
	PORTD = c<<4;
	PORTB |= _BV(E);
	PORTB &= ~_BV(E);
	_delay_ms(DELAY);
}
void f4BitWriteDat(tByte d) {
	PORTB |= _BV(RS);
	PORTD = d;
	PORTB |= _BV(E);
	PORTB &= ~_BV(E);
	PORTD = d<<4;
	PORTB |= _BV(E);
	PORTB &= ~_BV(E);
	_delay_ms(DELAY);
}
void f8BitInitLCD(void) {
	f8BitWriteCmd(0b00111000); // Function set, 8 bit, 2 lines, 5x7
	f8BitWriteCmd(0b00001111); // Display ON, Cursor On, Cursor Blinking
	f8BitWriteCmd(0b00000110); // Entry Mode, Increment cursor position,
	// No display shift
	f8BitWriteCmd(0x01); // Clear screen
	f8BitWriteCmd(0x02); // Return home
}
void f4BitInitLCD(void) {
	f4BitWriteCmd(0b00101000); // Function set, 4 bit, 2 lines, 5x7
	f4BitWriteCmd(0b00001111); // Display ON, Cursor On, Cursor Blinking
	f4BitWriteCmd(0b00000110); // Entry Mode, Increment cursor position,
	// No display shift
	f4BitWriteCmd(0x01); // Clear screen
	f4BitWriteCmd(0x02); // Return home
}
void f4BitWriteStr(tByte l,tByte *s) {
	if (l==1)
	{
		f4BitWriteCmd(0b10000000);
	}
	else{
		f4BitWriteCmd(0b11000000);
	}
	int length = strlen(s);
	int i=0;
	//while(s[i] != '\0'){
	for(i=0;i<length;i++){
		f4BitWriteDat(s[i]);
		//i++;
	}
}
int main(void) {
	tByte s[BUF_SIZE];
	DDRD |= 0xFF; // PD0-7 as D0-D7
	DDRB |= (1<<E)|(1<<RS); // PB0-1 as RS & E, respectively
	_delay_ms(50); // Wait for LCD startup
	f4BitInitLCD();
	/*f4BitWriteCmd(0b10000000); // Start of line 1
	f4BitWriteDat('H');
	f4BitWriteDat('e');
	f4BitWriteDat('l');
	f4BitWriteDat('l');
	f4BitWriteDat('o');
	f4BitWriteDat(0x20); // Write a space
	f4BitWriteDat('W');
	f4BitWriteDat('o');
	f4BitWriteDat('r');
	f4BitWriteDat('l');
	f4BitWriteDat('d');
	f4BitWriteCmd(0b11000000); // Start of line 2
	f4BitWriteDat('C');
	f4BitWriteDat('S');
	f4BitWriteDat('S');
	f4BitWriteDat('3');
	f4BitWriteDat('3');
	f4BitWriteDat('2');*/
	f4BitWriteStr(1,"Prayuth");
	f4BitWriteStr(2,"Dictator 44");
	
	while (1) {}
	return 0;
}