#include <avr/io.h>
#include <stdio.h>
#define F_CPU 16000000UL
#define BAUD 9600
#include <util/setbaud.h>
#define tByte uint8_t // byte data (8bits)
#define tWord uint16_t // word data (16bits)
void uart_putchar(char c, FILE *stream) {
	if (c == '\n') uart_putchar('\r', stream);
	loop_until_bit_is_set(UCSR0A, UDRE0);
	UDR0 = c;
}
char uart_getchar(FILE *stream) {
	loop_until_bit_is_set(UCSR0A, RXC0);
	return UDR0;
}
FILE uart_output = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);
FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getchar, _FDEV_SETUP_READ);
void fPrintfInit(void) {
	UBRR0H = UBRRH_VALUE;
	UBRR0L = UBRRL_VALUE;
	UCSR0A &= ~(_BV(U2X0));
	UCSR0C = _BV(UCSZ01) | _BV(UCSZ00);
	UCSR0B = _BV(RXEN0) | _BV(TXEN0);
	stdout = &uart_output;
	stdin = &uart_input;
}
void fEEWrByte(tWord addr, tByte dat) {
	// Wait for completion of previous write
	while(EECR & (1<<EEPE));
	// Set up address and Data Registers
	EEAR = addr;
	EEDR = dat;
	// Write logical one to EEMPE
	EECR |= (1<<EEMPE);
	// Start eeprom write by setting EEPE
	EECR |= (1<<EEPE);
}
tByte fEERdByte(tWord addr) {
	// Wait for completion of previous write
	while(EECR & (1<<EEPE));
	// Set up address register
	EEAR = addr;
	// Start eeprom read by writing EERE
	EECR |= (1<<EERE);
	return EEDR;
}
void fEEWrStr(tWord addr,tByte *s) {
	while (*s!='\0') fEEWrByte(addr++,*s++);
}
void fEERdStr(tWord addr) {
	tByte d=0;
	while (d!='\n') {d=fEERdByte(addr++);printf("%c",d);}
}
int main(void) {
	fPrintfInit(); // Init printf
	fEEWrByte(0,123); // Write a byte to EEPROM
	printf("Data=%d\n",fEERdByte(0)); // Read a byte from EEPROM
	fEEWrStr(1,"Hello World\n"); // Write bytes to EEPROM
	fEERdStr(1); // Read bytes from EEPROM
	while (1) {}
}